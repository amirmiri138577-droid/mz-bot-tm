# اجرای MirzaBot روی Railway

این مخزن اکنون Dockerfile و startup مخصوص Railway دارد. این مسیر، نصاب Ubuntu در `install.sh` را اجرا نمی‌کند؛ اپلیکیشن PHP را در کانتینر Apache بالا می‌آورد، به MySQL جداگانه Railway متصل می‌شود، جدول‌ها را ایجاد می‌کند و webhook تلگرام را ثبت می‌کند.

## راه‌اندازی

1. این مخزن را Fork کنید و در Railway یک پروژه بسازید. سرویس اپ را از مخزن خودتان اضافه کنید؛ Railway فایل `Dockerfile` را به‌طور خودکار تشخیص می‌دهد.
2. در همان پروژه یک سرویس **MySQL** بسازید. از بخش Variables آن، متغیرهای MySQL را به‌صورت Reference Variables به سرویس MirzaBot متصل کنید.
3. در سرویس MirzaBot بخش **Settings → Networking** را باز کنید و **Generate Domain** را بزنید. دامنه عمومی HTTPS لازم است تا Telegram بتواند webhook را فراخوانی کند. برنامه از `RAILWAY_PUBLIC_DOMAIN` استفاده می‌کند؛ در صورت نیاز می‌توانید `APP_DOMAIN` را با hostname بدون `https://` تنظیم کنید.
4. متغیرهای زیر را در سرویس MirzaBot وارد کنید:

| متغیر | مقدار |
|---|---|
| `BOT_TOKEN` | توکن ربات از BotFather |
| `ADMIN_ID` | شناسه عددی تلگرام مدیر اصلی |
| `BOT_USERNAME` | نام کاربری ربات بدون `@` |
| `MYSQLHOST` | Reference به `MYSQLHOST` سرویس MySQL |
| `MYSQLPORT` | Reference به `MYSQLPORT` سرویس MySQL |
| `MYSQLDATABASE` | Reference به `MYSQLDATABASE` سرویس MySQL |
| `MYSQLUSER` | Reference به `MYSQLUSER` سرویس MySQL |
| `MYSQLPASSWORD` | Reference به `MYSQLPASSWORD` سرویس MySQL |

می‌توانید به‌جای متغیرهای MySQL از `DATABASE_URL` یا معادل‌های عمومی `DB_HOST`, `DB_PORT`, `DB_NAME`, `DB_USER`, `DB_PASSWORD` استفاده کنید. برای hostname دامنه Railway کافی است Generate Domain را انجام دهید؛ اگر دامنه خودتان را دارید، `APP_DOMAIN` را روی hostname همان دامنه بگذارید.

5. در سرویس MySQL یک Railway Volume متصل کنید تا دیتابیس پس از بازسازی کانتینر از بین نرود. در سرویس MirzaBot نیز یک Volume به مسیر `/var/www/html/storage` وصل کنید تا وضعیت زمان‌بندی، cache و فایل‌های داخلی storage حفظ شوند.
6. Deploy کنید. در startup، کانتینر منتظر اتصال دیتابیس می‌ماند، `table.php` را برای ایجاد/به‌روزرسانی schema اجرا می‌کند و webhook را به `https://<دامنه>/index.php?secret=...` ثبت می‌کند.

در صورت تمایل، در تنظیمات سرویس و قسمت Healthcheck Path مقدار `/healthz.php` را قرار دهید.

## نکات مهم

- این سرویس باید همیشه فعال بماند. زمان‌بند داخلی پروژه همراه وب‌سرور اجرا می‌شود و `cronbot/run.php` را تقریباً هر دقیقه صدا می‌زند؛ این لازم است چون چند job پروژه فاصله یک‌دقیقه‌ای دارند. Cron Job استاندارد Railway حداقل فاصلهٔ پنج‌دقیقه‌ای دارد و جایگزین مناسبی برای این jobها نیست.
- سرویس MirzaBot را روی **یک replica** نگه دارید؛ چند replica می‌توانند زمان‌بند را هم‌زمان اجرا کنند. اگر زمان‌بند را جدا کرده‌اید، می‌توانید در سرویس وب `ENABLE_CRON=0` بگذارید.
- `storage` را پایدار کنید. Volume دیتابیس باید به سرویس MySQL وصل باشد، نه به مسیرهای اپلیکیشن.
- مقادیر حساس را فقط در Railway Variables قرار دهید. آن‌ها را در Git یا در پیام‌ها قرار ندهید.
- دسترسی بیرونی به سرویس‌ها و پنل‌های VPN شما باید از Railway قابل‌دسترسی باشد. در صورت محدودیت IP یا firewall، اتصال اپ به آن پنل‌ها برقرار نخواهد شد.
- وب‌هوک در هر شروع سرویس با دامنه فعلی تنظیم می‌شود. بعد از تغییر دامنه، سرویس را redeploy کنید.

## عیب‌یابی

- اگر Deploy پیش از شروع Apache متوقف شد، در Logs به خطای MySQL یا متغیرهای گمشده توجه کنید؛ نام متغیرها باید دقیقاً مطابق جدول باشد.
- برای آزمودن در دسترس بودن HTTP، endpoint `/healthz.php` باید پاسخ `ok` بدهد.
- برای بررسی زمان‌بند، فایل `storage/cron_status.json` را در Volume نگه دارید و لاگ‌های سرویس را بررسی کنید.
- `install.sh` برای سرور Ubuntu و دسترسی به systemd/apt نوشته شده است؛ آن را در Railway اجرا نکنید.
