<?php
// Environment-backed configuration for container platforms such as Railway.
// The standard Ubuntu installer writes its own config.php with literal values;
// these defaults also preserve compatibility with existing placeholder-based installs.
$request_exec_timeout = null;
$mirzaEnv = static function (array $names, string $default = ''): string {
    foreach ($names as $name) {
        $value = getenv($name);
        if ($value !== false && $value !== '') {
            return (string) $value;
        }
    }
    return $default;
};

$databaseUrl = $mirzaEnv(['DATABASE_URL']);
$databaseUrlParts = $databaseUrl !== '' ? parse_url($databaseUrl) : false;
$databaseUrlParts = is_array($databaseUrlParts) ? $databaseUrlParts : [];

$dbhost = $mirzaEnv(['MYSQLHOST', 'DB_HOST'], (string) ($databaseUrlParts['host'] ?? '{database_url}'));
$dbport = $mirzaEnv(['MYSQLPORT', 'DB_PORT'], isset($databaseUrlParts['port']) ? (string) $databaseUrlParts['port'] : '');
$dbname = $mirzaEnv(
    ['MYSQLDATABASE', 'DB_NAME'],
    isset($databaseUrlParts['path']) ? ltrim(rawurldecode($databaseUrlParts['path']), '/') : '{database_name}'
);
$usernamedb = $mirzaEnv(['MYSQLUSER', 'DB_USER'], isset($databaseUrlParts['user']) ? rawurldecode($databaseUrlParts['user']) : '{username_db}');
$passworddb = $mirzaEnv(['MYSQLPASSWORD', 'DB_PASSWORD'], isset($databaseUrlParts['pass']) ? rawurldecode($databaseUrlParts['pass']) : '{password_db}');

$options = [
    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
    PDO::ATTR_EMULATE_PREPARES => false,
    PDO::MYSQL_ATTR_INIT_COMMAND => "SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci",
];
$dsn = "mysql:host=$dbhost" . ($dbport !== '' ? ";port=$dbport" : '') . ";dbname=$dbname;charset=utf8mb4";
try {
    $pdo = new PDO($dsn, $usernamedb, $passworddb, $options);
} catch (\PDOException $e) {
    error_log("Database connection failed: " . $e->getMessage());
    die("error: database connection failed");
}

$APIKEY = $mirzaEnv(['BOT_TOKEN', 'APIKEY'], '{API_KEY}');
$adminnumber = $mirzaEnv(['ADMIN_ID', 'ADMIN_NUMBER'], '{admin_number}');
$domainValue = $mirzaEnv(
    ['APP_DOMAIN', 'RAILWAY_PUBLIC_DOMAIN', 'DOMAIN_NAME', 'APP_URL'],
    '{domain_name}'
);
$domainWithScheme = strpos($domainValue, '://') === false ? 'https://' . $domainValue : $domainValue;
$domainHost = parse_url($domainWithScheme, PHP_URL_HOST);
$domainhosts = is_string($domainHost) && $domainHost !== '' ? $domainHost : trim($domainValue, '/');
$usernamebot = ltrim($mirzaEnv(['BOT_USERNAME', 'USERNAME_BOT'], '{username_bot}'), '@');
?>
