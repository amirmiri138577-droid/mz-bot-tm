#!/usr/bin/env bash
set -Eeuo pipefail

APP_DIR=/var/www/html
PORT="${PORT:-8080}"

if [[ ! "$PORT" =~ ^[0-9]+$ ]]; then
    echo "PORT must be a numeric TCP port." >&2
    exit 1
fi

if [[ -z "${BOT_TOKEN:-${APIKEY:-}}" ]]; then
    echo "Missing BOT_TOKEN (or APIKEY) Railway variable." >&2
    exit 1
fi
if [[ -z "${ADMIN_ID:-${ADMIN_NUMBER:-}}" ]]; then
    echo "Missing ADMIN_ID (or ADMIN_NUMBER) Railway variable." >&2
    exit 1
fi
if [[ -z "${MYSQLHOST:-${DB_HOST:-}}" && -z "${DATABASE_URL:-}" ]]; then
    echo "Set Railway MySQL variables (MYSQLHOST, MYSQLDATABASE, MYSQLUSER, MYSQLPASSWORD) or DATABASE_URL." >&2
    exit 1
fi
if [[ -z "${APP_DOMAIN:-${RAILWAY_PUBLIC_DOMAIN:-${DOMAIN_NAME:-${APP_URL:-}}}}" ]]; then
    echo "Generate a Railway domain or set APP_DOMAIN before deploying; Telegram needs an HTTPS webhook URL." >&2
    exit 1
fi

# Railway's assigned port is only known at runtime.
sed -i -E "s/^Listen [0-9]+$/Listen ${PORT}/" /etc/apache2/ports.conf
sed -i -E "s/<VirtualHost \*:([0-9]+)>/<VirtualHost *:${PORT}>/" /etc/apache2/sites-enabled/000-default.conf

mkdir -p "$APP_DIR/storage/cache"
# A mounted Railway Volume hides the image's .htaccess, so restore the deny rules.
cat > "$APP_DIR/storage/.htaccess" <<'HTACCESS'
Options -Indexes
<FilesMatch "^error_log$|\.log$|\.log\.[0-9]+$|\.(json|sql|zip)$">
    Require all denied
</FilesMatch>
HTACCESS
chown -R www-data:www-data "$APP_DIR/storage" "$APP_DIR/cronbot"
chmod -R u+rwX,g+rwX "$APP_DIR/storage" "$APP_DIR/cronbot"

# Wait for Railway's MySQL service to become reachable before applying the schema.
ready=0
for attempt in $(seq 1 60); do
    if php -r 'require "/var/www/html/config.php";' >/dev/null 2>&1; then
        ready=1
        break
    fi
    echo "Waiting for MySQL (${attempt}/60)..."
    sleep 2
done
if [[ "$ready" -ne 1 ]]; then
    echo "Could not connect to MySQL after 120 seconds; check Railway database variables." >&2
    exit 1
fi

# Idempotently create/update tables and register the Telegram webhook.
php "$APP_DIR/table.php"

cron_loop() {
    while true; do
        php "$APP_DIR/cronbot/run.php" || echo "Mirza cron dispatcher exited with an error." >&2
        now=$(date +%s)
        sleep_for=$((60 - now % 60))
        sleep "$sleep_for"
    done
}

CRON_PID=""
if [[ "${ENABLE_CRON:-1}" != "0" ]]; then
    cron_loop &
    CRON_PID=$!
fi

apache2-foreground &
APACHE_PID=$!

cleanup() {
    [[ -n "$CRON_PID" ]] && kill -TERM "$CRON_PID" 2>/dev/null || true
    [[ -n "$APACHE_PID" ]] && kill -TERM "$APACHE_PID" 2>/dev/null || true
    [[ -n "$CRON_PID" ]] && wait "$CRON_PID" 2>/dev/null || true
    [[ -n "$APACHE_PID" ]] && wait "$APACHE_PID" 2>/dev/null || true
}
trap cleanup TERM INT EXIT
wait "$APACHE_PID"
